package com.project.main;

import android.app.Activity;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.view.View.OnClickListener;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

public class MainActivity extends Activity
{
    /** Called when the activity is first created. */
    ProgressBar pgr;
    WebView web;
    LinearLayout main,webV,log;
    int progress = 0;
    
    Handler h = new Handler();
    @Override
    public void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        
        setContentView(R.layout.main);
        web = (WebView)findViewById(R.id.webView1);
        web.setWebViewClient(new myWebViewClient());
        web.getSettings().setJavaScriptEnabled(true);
        web.loadUrl("http://104.238.94.166:82/");
        
    }
    public class myWebViewClient extends WebViewClient
    {
        
        @Override
        public void onPageFinished(WebView view, String url){
            
            super.onPageFinished(view, url);
        }
        @Override
        public void onPageStarted(WebView view, String url, Bitmap favicon){
            super.onPageStarted(view, url, favicon);
        }
        
        @Override
        public boolean shouldOverrideUrlLoading(WebView view, String url){         
            view.loadUrl(url);
            return true;
        }
        
    }
}

